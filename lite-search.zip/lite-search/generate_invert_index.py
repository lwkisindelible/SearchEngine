import csv

with open('temp_index.csv') as f:
    f_csv = csv.reader(f)
    word_c = 1
    page_c = 1
    invertIndex = [str]
    tempString = ""
    for index, value in enumerate(f_csv):
        if index == 0:
            temp = value
            tempString += (str(temp[0]) + ',{')
            continue
        else:
            if temp == value:
                word_c = word_c + 1
            else:
                if temp[0] == value[0]:
                    tempString += (str(temp[1]) + '[' + str(word_c) + ']')
                    word_c = 1
                    temp = value
                    page_c = page_c + 1
                else:
                    if page_c == 1:
                        tempString += (str(temp[1]) + '[1]')
                    invertIndex.append(tempString+'}')
                    tempString = ""+(str(value[0]) + ',{')
                    temp = value
                    page_c = 1
                    continue
with open('invert_index.csv', 'w+') as iif:
    for i in invertIndex:
        iif.write(str(i)+',\n')

print('倒排索引文件生成完毕')