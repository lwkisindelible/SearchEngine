# -*- coding: UTF-8 -*-
import jieba
import logging
import re
import csv
import math
import time

jieba.setLogLevel(logging.INFO)


def find_word_index(w):
    with open("word_index.csv", encoding="utf-8") as wi:
        wi_csv = csv.reader(wi)
        for row in wi_csv:
            if row[1] == w:
                return row[0]


def get_invert_index(id):
    with open("invert_index.csv") as f:
        f_csv = csv.reader(f)
        for row in f_csv:
            if not row[0].isdigit():
                continue
            if id == row[0]:
                return row[1]


def cnt_page():
    p_cnt = 0
    with open("zhnews.csv", encoding='utf-8') as f:
        f_csv = csv.reader(f)
        for _ in f_csv:
            p_cnt = p_cnt + 1
    return p_cnt


def partition(arr, low, high):
    i = (low - 1)  # 最小元素索引
    pivot = arr[high]['tfidf']
    for j in range(low, high):
        # 当前元素小于或等于 pivot
        if arr[j]['tfidf'] <= pivot:
            i = i + 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def quick_sort(arr, low, high):
    if arr[low]['tfidf'] < arr[high]['tfidf']:
        pi = partition(arr, low, high)
        quick_sort(arr, low, pi - 1)
        quick_sort(arr, pi + 1, high)


def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key["tfidf"] < arr[j]["tfidf"]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key


def res_sort(result):
    insertion_sort(result)
    return result


def print_res(result):
    i = len(result) - 1
    if i < 0:
        print('我们没有找到相关的搜索结果，换个搜索词试试？')
        return
    p = 1
    while i >= len(result) - 10:
        print(str(p) + '. ' + result[i]['title'] + ' [tf-idf=' + str(round(result[i]['tfidf'], 5)) \
              + ']\n' + result[i]['web'] + '\n')
        i = i - 1
        p = p + 1
        if i == -1:
            break


cnt_p = cnt_page()
print("\033[1;35m -= search in sh.people.com.cn =- \033[0m", )
pages = []
# tfidf = [{'tf': str, 'idf': float}]
with open('page.csv', encoding='utf-8') as f:
    f_csv = csv.reader(f)
    for row in f_csv:
        pages.append(row)
while True:
    try:
        t_result = []  # [{'id': int, 'web': str, 'title': str, 'tfidf': float}]
        exist = []
        in_str = input("搜索: ").strip().replace(' ', '').replace('\r', '').replace('\t', '')
        tmp = re.sub(u"([^\u4e00-\u9fa5\u0030-\u0039\u0041-\u005a\u0061-\u007a])", '', in_str)
        tic1 = time.perf_counter()
        cuts = jieba.lcut(tmp)
        for cw in cuts:
            p = []
            try:
                line = get_invert_index(find_word_index(cw)).lstrip('{').rstrip('}').split(']')
            except:
                continue
            pt_cnt = 0
            for page in line:
                if page == '':
                    continue
                p.append(page.split('['))
                pt_cnt = pt_cnt + 1
            idf = math.log10(cnt_p / pt_cnt + 1)  # 计算idf的值
            for each in p:  # each[0]是页面编号，each[1]是词频
                t_tfidf = float(int(each[1]) / int(pages[int(each[0])][1])) * idf
                t_page = pages[int(each[0])]  # 这里的4应该改成each[0],为了测试方便固定成4了
                # 找到列表中对应的字典
                if exist.count(each[0]):
                    continue
                else:
                    exist.append(each[0])
                    t_result.append({'id': int(each[0]), 'web': t_page[3], 'title': t_page[2],
                                     'tfidf': t_tfidf})
        res = res_sort(t_result)
        toc1 = time.perf_counter()
        print('搜索耗时: {}s'.format(round((toc1 - tic1), 5)))
        print_res(res)
    except:
        break
