# -*- coding: UTF-8 -*-
import re
import csv


class TreeNode(object):
    def __init__(self):
        self.id = None
        self.nodes = {}  # 记录当前结点的子结点
        self.is_leaf = False  # 当前结点是否表示一个单词
        self.count = 0  # 单词树中单词的总量

    def insert(self, word):
        curr = self
        for c in word:
            if not curr.nodes.get(c, None):
                new_node = TreeNode()
                curr.nodes[c] = new_node
            curr = curr.nodes[c]
        curr.is_leaf = True
        curr.id = self.count + 1
        self.count += 1
        return curr.id

    def insert_many(self, words):
        for word in words:
            self.insert(word)
        return

    def search(self, word):
        curr = self
        try:
            for c in word:
                curr = curr.nodes[c]
        except:
            return -1
        return curr.id if curr.is_leaf else -1


pages = []  # [{'pid': int, 'wcnt':int, 'title': str, 'web':str}]
pid = 0
t_index = []
w_list= []

with open('zhnews.csv', 'r', encoding='utf-8') as tf:
    tf_csv = csv.reader(tf)
    tree = TreeNode()
    for row in tf_csv:
        title = re.sub('#', '', row[1])
        wcnt = row[1].count('#') + row[2].count('#') + 2
        pages.append({'pid': pid, 'wcnt': wcnt, 'title': title, 'web': row[0]})
        t_list = row[1].split('#') + row[2].split('#')
        for word in t_list:
            sch = tree.search(word)
            if sch == -1:
                temp_id = tree.insert(word)
                w_list.append({'wid': temp_id, 'word': word})
            else:
                temp_id = sch
            t_index.append({'tid': temp_id, 'pid': pid})
        pid = pid + 1
t_index.sort(key=lambda x:x['tid'])
with open('page.csv', 'w+', encoding='utf-8', newline='') as pf:
    headers = [k for k in pages[0]]
    writer = csv.DictWriter(pf, fieldnames=headers)
    for page in pages:
        writer.writerow(page)
with open('temp_index.csv', 'w+', encoding='utf-8', newline='') as tempf:
    headers = [k for k in t_index[0]]
    writer = csv.DictWriter(tempf, fieldnames=headers)
    for row in t_index:
        writer.writerow(row)
with open('word_index.csv', 'w+', encoding='utf-8', newline='') as tempw:
    headers = [k for k in w_list[0]]
    writer = csv.DictWriter(tempw, fieldnames=headers)
    for row in w_list:
        writer.writerow(row)

print('单词索引、页面文件和临时索引文件生成完毕')
