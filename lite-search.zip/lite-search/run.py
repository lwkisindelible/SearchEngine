import os

cmd = 'python generate_page_files.py'
os.system(cmd)
cmd = 'python generate_invert_index.py'
os.system(cmd)
cmd = 'python search.py'
os.system(cmd)
